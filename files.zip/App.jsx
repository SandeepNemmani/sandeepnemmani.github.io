import { useState, useEffect, useRef } from "react";
import "./App.css";

const data = {
  name: "Sandeep Nemmani",
  title: "Senior Supply Chain Manager",
  tagline: "9 years turning inventory chaos into operational clarity — at Tesla scale.",
  about: `I'm a supply chain leader with deep roots in automotive service parts, demand planning, and cross-functional procurement. At Tesla, I manage a team of 11 material planners across a 10,000+ SKU North American service parts network. I thrive at the intersection of data, systems, and people — reducing costs, minimizing excess inventory, and building processes that scale.\n\nI hold an M.S. in Industrial Engineering from Texas A&M and bring hands-on fluency in MRP/ERP systems, inventory health optimization, and executive-level stakeholder communication.`,
  location: "San Francisco, CA",
  email: "sandeep.nemmani@email.com",
  linkedin: "linkedin.com/in/sandeepnemmani",
  experience: [
    {
      company: "Tesla",
      role: "Supply Chain Manager — Service Parts",
      period: "2016 – Present",
      bullets: [
        "Lead 11 material planners across a 10,000+ SKU North American service parts network",
        "Drove multi-million dollar logistics cost reductions through carrier optimization and routing improvements",
        "Reduced excess inventory by 30%+ through demand signal refinement and supplier collaboration",
        "Maintained top-tier inventory health metrics consistently above organizational benchmarks",
        "Spearheaded Last-Time-Buy (LTB) procurement workflows adopted across NA service operations",
      ],
    },
    {
      company: "Prior Experience",
      role: "Supply Chain & Operations Roles",
      period: "2014 – 2016",
      bullets: [
        "Built foundational expertise in MRP/ERP systems, S&OP processes, and supplier management",
        "Developed demand forecasting frameworks using statistical modeling and historical trend analysis",
        "Collaborated cross-functionally with engineering, procurement, and finance teams",
      ],
    },
  ],
  projects: [
    {
      title: "LTB Procurement Workflow",
      tags: ["Process Design", "Executive Ops"],
      desc: "Designed and deployed a Last-Time-Buy procurement workflow for end-of-life parts, adopted across Tesla's North American service operations. Reduced procurement lead time and improved decision traceability.",
    },
    {
      title: "Supply Continuity Framework",
      tags: ["Risk Mgmt", "MRP Systems"],
      desc: "Built a supply continuity decision workflow handling escalation paths and supplier action tracking. Reduced part outages through proactive risk tiering.",
    },
    {
      title: "Demand Forecasting Model",
      tags: ["Python", "ARIMA", "Analytics"],
      desc: "Developed an ARIMA-based demand forecasting pipeline for service parts with high seasonality. Improved forecast accuracy and reduced stockouts across high-velocity SKUs.",
    },
    {
      title: "Inventory Health Dashboard",
      tags: ["Data Analysis", "KPIs"],
      desc: "Designed KPI tracking framework for inventory health across 10,000+ SKUs. Delivered weekly executive reporting with clear metric ownership at the planner level.",
    },
  ],
  skills: ["Inventory Planning", "MRP/ERP Systems", "Demand Forecasting", "S&OP", "Supplier Management", "Cross-functional Leadership", "Python", "Data Analysis", "Process Design", "Executive Communication"],
  education: { degree: "M.S. Industrial Engineering", school: "Texas A&M University" },
};

function useInView(threshold = 0.15) {
  const ref = useRef(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setInView(true); }, { threshold });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return [ref, inView];
}

function Section({ id, children, className = "" }) {
  const [ref, inView] = useInView();
  return (
    <section id={id} ref={ref} className={`section ${inView ? "visible" : ""} ${className}`}>
      {children}
    </section>
  );
}

function Nav({ active }) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);
  const links = ["about", "experience", "projects", "contact"];
  return (
    <nav className={scrolled ? "scrolled" : ""}>
      <span className="nav-name">{data.name.split(" ")[0]}<span className="dot">.</span></span>
      <ul>
        {links.map(l => (
          <li key={l}><a href={`#${l}`} className={active === l ? "active" : ""}>{l}</a></li>
        ))}
      </ul>
    </nav>
  );
}

export default function App() {
  const [active, setActive] = useState("about");
  useEffect(() => {
    const sections = document.querySelectorAll("section[id]");
    const obs = new IntersectionObserver(
      entries => entries.forEach(e => { if (e.isIntersecting) setActive(e.target.id); }),
      { threshold: 0.4 }
    );
    sections.forEach(s => obs.observe(s));
    return () => obs.disconnect();
  }, []);

  return (
    <>
      <Nav active={active} />
      <header className="hero">
        <div className="hero-inner">
          <p className="hero-label">Supply Chain Leadership</p>
          <h1>{data.name}</h1>
          <p className="hero-role">{data.title}</p>
          <p className="hero-tagline">{data.tagline}</p>
          <div className="hero-cta">
            <a href="#experience" className="btn-primary">View Experience</a>
            <a href="#contact" className="btn-ghost">Get in Touch</a>
          </div>
        </div>
        <div className="hero-deco" aria-hidden="true">
          <div className="deco-stat"><span>10K+</span><small>SKUs managed</small></div>
          <div className="deco-stat"><span>11</span><small>Planners led</small></div>
          <div className="deco-stat"><span>9yr</span><small>Industry tenure</small></div>
        </div>
      </header>

      <Section id="about">
        <div className="about-grid">
          <div className="about-text">
            <h2>About</h2>
            {data.about.split("\\n\\n").map((p, i) => <p key={i}>{p}</p>)}
            <p className="edu-line">🎓 {data.education.degree} — {data.education.school}</p>
          </div>
          <div className="skills-col">
            <h3>Core Skills</h3>
            <div className="skill-pills">
              {data.skills.map(s => <span key={s} className="pill">{s}</span>)}
            </div>
          </div>
        </div>
      </Section>

      <Section id="experience" className="alt-bg">
        <h2>Experience</h2>
        <div className="exp-list">
          {data.experience.map((job, i) => (
            <div key={i} className="exp-card">
              <div className="exp-header">
                <div>
                  <h3>{job.role}</h3>
                  <span className="company">{job.company}</span>
                </div>
                <span className="period">{job.period}</span>
              </div>
              <ul className="exp-bullets">
                {job.bullets.map((b, j) => <li key={j}>{b}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      <Section id="projects">
        <h2>Projects</h2>
        <div className="proj-grid">
          {data.projects.map((p, i) => (
            <div key={i} className="proj-card">
              <div className="proj-tags">{p.tags.map(t => <span key={t} className="tag">{t}</span>)}</div>
              <h3>{p.title}</h3>
              <p>{p.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section id="contact" className="alt-bg">
        <div className="contact-inner">
          <h2>Let's connect</h2>
          <p>Open to senior supply chain leadership opportunities — especially in hardware, robotics, or high-growth tech.</p>
          <div className="contact-links">
            <a href={`mailto:${data.email}`} className="contact-item">
              <span className="contact-icon">✉</span><span>{data.email}</span>
            </a>
            <a href={`https://${data.linkedin}`} target="_blank" rel="noreferrer" className="contact-item">
              <span className="contact-icon">in</span><span>{data.linkedin}</span>
            </a>
            <span className="contact-item">
              <span className="contact-icon">📍</span><span>{data.location}</span>
            </span>
          </div>
        </div>
      </Section>

      <footer><p>© {new Date().getFullYear()} {data.name} · Built with React</p></footer>
    </>
  );
}
